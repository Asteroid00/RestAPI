﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace StudentAdmissionAppApi.Migrations
{
    public partial class alltables : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Stages",
                columns: table => new
                {
                    StageId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StageName = table.Column<string>(type: "varchar(20)", unicode: false, maxLength: 20, nullable: false),
                    StageDescription = table.Column<string>(type: "varchar(max)", unicode: false, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK__Stages__03EB7AD80BD5AB62", x => x.StageId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FirstName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    LastName = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    LoginId = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    ContactNumber = table.Column<string>(type: "nvarchar(15)", maxLength: 15, nullable: false),
                    PasswordHash = table.Column<byte[]>(type: "varbinary(max)", nullable: false),
                    PasswordSalt = table.Column<byte[]>(type: "varbinary(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "Standards",
                columns: table => new
                {
                    StandardId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StandardName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    ClassTeacherName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: true),
                    StageId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Standards", x => x.StandardId);
                    table.ForeignKey(
                        name: "FK_Standards_Standards",
                        column: x => x.StageId,
                        principalTable: "Stages",
                        principalColumn: "StageId");
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    StudentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    StageId = table.Column<int>(type: "int", nullable: false),
                    StandardId = table.Column<int>(type: "int", nullable: false),
                    StudentName = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    StudentEmail = table.Column<string>(type: "varchar(50)", unicode: false, maxLength: 50, nullable: false),
                    IsPhysicallyDisabled = table.Column<bool>(type: "bit", nullable: false),
                    Gender = table.Column<string>(type: "varchar(1)", unicode: false, maxLength: 1, nullable: false),
                    DateOfApplication = table.Column<DateTime>(type: "date", nullable: false),
                    Image = table.Column<string>(type: "varchar(150)", unicode: false, maxLength: 150, nullable: true),
                    Maths = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    Science = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    SocialStudies = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    Hindi = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    English = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    Chemistry = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    Biology = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    Physics = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    TotalMarks = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    Percentages = table.Column<decimal>(type: "decimal(18,0)", nullable: true),
                    IsAdmisisonConfirmed = table.Column<bool>(type: "bit", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.StudentId);
                    table.ForeignKey(
                        name: "FK_Students_Stages",
                        column: x => x.StageId,
                        principalTable: "Stages",
                        principalColumn: "StageId");
                    table.ForeignKey(
                        name: "FK_Students_Standards",
                        column: x => x.StandardId,
                        principalTable: "Standards",
                        principalColumn: "StandardId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Standards_StageId",
                table: "Standards",
                column: "StageId");

            migrationBuilder.CreateIndex(
                name: "IX_Students_StageId",
                table: "Students",
                column: "StageId");

            migrationBuilder.CreateIndex(
                name: "IX_Students_StandardId",
                table: "Students",
                column: "StandardId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Standards");

            migrationBuilder.DropTable(
                name: "Stages");
        }
    }
}
