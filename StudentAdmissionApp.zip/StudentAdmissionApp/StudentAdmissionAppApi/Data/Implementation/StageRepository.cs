﻿using StudentAdmissionAppApi.Data.Contract;
using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Implementation
{
    public class StageRepository : IStageRepository
    {
        private readonly AppDBContext _appDbContext;

        public StageRepository(AppDBContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public IEnumerable<Stages> GetStage()
        {
            List<Stages> stages = _appDbContext.Stages.ToList();
            return stages;
        }


        public Stages?  GetStageById(int id)
        {
            var stages = _appDbContext.Stages.FirstOrDefault(c => c.StageId == id);
            return stages;
        }

        public bool AddStage(Stages stages)
        {
            var result = false;
            if (stages != null)
            {
                _appDbContext.Stages.Add(stages);
                _appDbContext.SaveChanges();
                result = true;
            }

            return result;
        }


        public bool UpdateStage(Stages stages)
        {
            var result = false;
            if (stages != null)
            {
                _appDbContext.Stages.Update(stages);
                _appDbContext.SaveChanges();
                result = true;
            }
            return result;
        }



        public bool GetAllStagesByNameAndDesc(string name)
        {
            var stages = _appDbContext.Stages.FirstOrDefault(C => C.StageName == name );
            if (stages != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool GetAllStagesByNameAndDesc(int stageId,string name)
        {
            var stages = _appDbContext.Stages.FirstOrDefault(C =>C.StageId != stageId && C.StageName == name );
            if (stages != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool DeleteStages(int id)
        {
            var result = false;
            var stage = _appDbContext.Stages.Find(id);
            if (stage != null)
            {
                _appDbContext.Stages.Remove(stage);
                _appDbContext.SaveChanges();
                result = true;
            }

            return result;
        }
    }
}
