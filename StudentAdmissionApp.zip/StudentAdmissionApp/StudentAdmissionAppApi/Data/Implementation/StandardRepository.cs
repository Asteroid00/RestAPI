﻿using Microsoft.EntityFrameworkCore;
using StudentAdmissionAppApi.Data.Contract;
using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Implementation
{
    public class StandardRepository : IStandardRepository
    {
        private readonly AppDBContext _dbContext;

        public StandardRepository(AppDBContext dbContext)
        {
            _dbContext = dbContext;
        }



        public IEnumerable<Standards> GetStandard()
        {
            List<Standards> standards = _dbContext.Standards.Include(C=>C.Stage).ToList();
            return standards;
        }



        public IEnumerable<Standards> GetPaginatedStandards(int page, int pageSize)
        {
            int skip = (page - 1) * pageSize;
            return _dbContext.Standards
                .OrderBy(c => c.StandardId)
                .Skip(skip)
                .Take(pageSize)
                .ToList();
        }



        public Standards GetStandardById(int id)
        {
            var standards = _dbContext.Standards.Include(p => p.Stage).FirstOrDefault(c => c.StandardId == id);
            return standards;
        }




        public IEnumerable<Standards> GetStandardByStageId(int id)
        {
            List<Standards> standards = _dbContext.Standards.Include(c => c.Stage).ToList();
            var result = standards.Where(p => p.StageId == id).ToList();
            return result;
        }



        public bool InsertStandard(Standards standards)
        {
            var result = false;
            if (standards != null)
            {
                _dbContext.Standards.Add(standards);
                _dbContext.SaveChanges();
                result = true;
            }

            return result;
        }



        public bool UpdateStandard(Standards standard)
        {
            var result = false;
            if (standard != null)
            {
                _dbContext.Standards.Update(standard);
                _dbContext.SaveChanges();
                result = true;
            }
            return result;
        }


        public bool DeleteStandard(int id)
        {
            var result = false;
            var standard = _dbContext.Standards.FirstOrDefault(s => s.StandardId == id);
            if (standard != null)
            {
                _dbContext.Standards.Remove(standard);
                _dbContext.SaveChanges();
                result = true;
            }

            return result;
        }
        public bool StandardExists(int standardId, string name)
        {
            var standard = _dbContext.Standards.FirstOrDefault(c => c.StandardId != standardId && c.StandardName == name);
            if (standard != null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        public Standards GetStandardByStageIdAndStandardName(int stageId, string standardName)
        {
            var standard = _dbContext.Standards.FirstOrDefault(c => c.StageId == stageId && c.StandardName == standardName);
            return standard;
        }

        public Standards GetStandardByStageIdAndStandardName(int standardId, int stageId, string standardName)
        {
            var standard = _dbContext.Standards.FirstOrDefault(c => c.StandardId == standardId && c.StageId == stageId && c.StandardName == standardName);
            return standard;
        }



    }
}
