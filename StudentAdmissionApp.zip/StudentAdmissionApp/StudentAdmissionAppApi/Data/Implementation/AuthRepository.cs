﻿using StudentAdmissionAppApi.Data.Contract;
using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Implementation
{
    public class AuthRepository : IAuthRepository
    {
        private readonly AppDBContext _appDbContext;

        public AuthRepository(AppDBContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public bool RegisterUser(Users user)
        {
            var result = false;
            if (user != null)
            {
                _appDbContext.Users.Add(user);
                _appDbContext.SaveChanges();

                result = true;
            }
            return result;
        }

        public Users? ValidateUser(string username)
        {
            Users? user = _appDbContext.Users.FirstOrDefault(c => c.LoginId.ToLower() == username.ToLower() || c.Email == username.ToLower());
            return user;
        }

        public bool UserExists(string loginId, string email)
        {
            if (_appDbContext.Users.Any(c => c.LoginId.ToLower() == loginId.ToLower() || c.Email.ToLower() == email.ToLower()))
            {
                return true;
            }

            return false;
        }
    }
}
