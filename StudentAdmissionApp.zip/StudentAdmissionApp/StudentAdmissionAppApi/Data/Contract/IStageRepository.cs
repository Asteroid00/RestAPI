﻿using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Contract
{
    public interface IStageRepository
    {
        IEnumerable<Stages> GetStage();

        Stages? GetStageById(int id);

        bool AddStage(Stages stages);

        bool UpdateStage(Stages stages);

        bool GetAllStagesByNameAndDesc(string name);

        bool GetAllStagesByNameAndDesc(int stageId, string name);

        bool DeleteStages(int id);
    }
}
