﻿using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Contract
{
    public interface IStudentRepository
    {

         bool AddStudent(Students students);

         IEnumerable<Students> GetAllStudents();


         Students GetAllStudentsByNameAndEmail(string name, string email);


         Students GetStudents(int id);


         bool UpdateStudent(Students students);

        bool DeleteStudent(int id);


        /*IEnumerable<SP_StudentAdmissionResult> StudentAdmissionResults();*/
    }
}
