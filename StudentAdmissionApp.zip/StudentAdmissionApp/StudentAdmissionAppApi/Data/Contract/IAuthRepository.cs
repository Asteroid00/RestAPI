﻿using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Contract
{
    public interface IAuthRepository
    {
        public bool RegisterUser(Users user);

        public Users? ValidateUser(string username);

        public bool UserExists(string loginId, string email);
    }
}
