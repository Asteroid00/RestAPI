﻿using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Data.Contract
{
    public interface IStandardRepository
    {
        IEnumerable<Standards> GetStandard();

        IEnumerable<Standards> GetPaginatedStandards(int page, int pageSize);

        IEnumerable<Standards> GetStandardByStageId(int id);

        Standards? GetStandardById(int id);

        bool InsertStandard(Standards standards);

        bool UpdateStandard(Standards standard);

        bool DeleteStandard(int id);

        bool StandardExists(int standardId, string name);

        Standards GetStandardByStageIdAndStandardName( int stageId , string standardName);

        Standards GetStandardByStageIdAndStandardName(int standardId, int stageId, string standardName);
    }
}
