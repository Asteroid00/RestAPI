﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAdmissionAppApi.Dtos;
using StudentAdmissionAppApi.Models;
using StudentAdmissionAppApi.Service.Contract;
using StudentAdmissionAppApi.Service.Implementation;

namespace StudentAdmissionAppApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
   
    public class StandardController : ControllerBase
    {
        private readonly IStandardService _standardService;

        public StandardController(IStandardService standardService)
        {
            _standardService = standardService;
        }

        [HttpGet("GetAllStandardByPagination")]

        public IActionResult GetAllStandardByPagination(int page , int pageSize)
        {
            var response = _standardService.GetAllStandard(page,pageSize);
            if (!response.Success)
            {
                return NotFound(response);
            }
            return Ok(response);
        }


        [HttpGet("GetStandardById/{id}")]

        public IActionResult GetStandardById(int id)
        {
            var response = _standardService.GetStandardById(id);
            if (!response.Success)
            {
                return NotFound(response);
            }
            return Ok(response);

        }



        [HttpGet("GetAllStandardByStageId/{id}")]

        public IActionResult GetAllStandardByStageId(int id)
        {
            var response = _standardService.StandardByStageId(id);
            if (!response.Success)
            {
                return NotFound(response);
            }
            return Ok(response);
        }

        [HttpGet("GetAllStandardWithoutPage")]

        public IActionResult GetAllStandardWithoutPage()
        {
            var response = _standardService.GetAllStandardWithoutPage();
            if (!response.Success)
            {
                return NotFound(response);
            }
            return Ok(response);
        }


        [HttpPost("AddStandard")]

        public IActionResult AddStandard(AddStandardDto addStandardDto)
        {
            var standard = new Standards()
            {
                StageId = addStandardDto.StageId,
                StandardName = addStandardDto.StandardName,
                ClassTeacherName = addStandardDto.ClassTeacherName,

            };
            var result = _standardService.AddStandard(standard);
            return !result.Success ? BadRequest(result) : Ok(result);
        }


        [HttpPut("ModifyStandard")]

        public IActionResult UpdateStandard(UpdateStandardDto updateStandardDto)
        {
            var stage = new Standards()
            {
                StandardId = updateStandardDto.StandardId,
                StandardName = updateStandardDto.StandardName,
                ClassTeacherName = updateStandardDto.ClassTeacherName,
                StageId = updateStandardDto.StageId,
            };

            var response = _standardService.ModifyStandard(stage);

            if (!response.Success)
            {
                return BadRequest(response);

            }
            else
            {
                return Ok(response);
            }
        }
        [HttpDelete("Delete/{id}")]
        public IActionResult RemoveStandard(int id)
        {
            if (id > 0)
            {
                var response = _standardService.RemoveStandard(id);
                if (!response.Success)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }

            }
            else
            {
                return BadRequest("Please provide appropriate data.");
            }

        }


    }
}
