﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentAdmissionAppApi.Dtos;
using StudentAdmissionAppApi.Models;
using StudentAdmissionAppApi.Service.Contract;
using StudentAdmissionAppApi.Service.Implementation;

namespace StudentAdmissionAppApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    
    public class StageController : ControllerBase
    {
        private readonly IStageService _stageService;

        public StageController(IStageService stageService)
        {
            _stageService = stageService;
        }

        [HttpGet("GetAll")]
        public IActionResult GetAll()
        {
            var response = _stageService.GetAllStages();
            if (!response.Success)
            {
                return NotFound(response);
            }
            return Ok(response);
        }

        [HttpGet("GetStageById/{id}")]
        public IActionResult GetStageById(int id)
        {
            var response = _stageService.GetStageById(id);
            if (!response.Success)
            {
                return NotFound(response);
            }
            return Ok(response);
        }

        [HttpPost("AddStage")]
        public IActionResult AddStage(AddStageDto addStage)
        {

            var stage = new Stages
            {
                
                StageName = addStage.StageName,
                StageDescription = addStage.StageDescription,
                
            };

            var result = _stageService.AddStage(stage);
            return !result.Success ? BadRequest(result) : Ok(result);
        }


        [HttpPut("UpdateStage")]

        public IActionResult UpdateStage(UpdateStageDto stage)
        {
            var stages = new Stages()
            {
                StageId = stage.StageId,
                StageName = stage.StageName,
                StageDescription = stage.StageDescription,
                
            };

            var response = _stageService.UpdateStage(stages);

            if (!response.Success)
            {
                return BadRequest(response);
            }
            else
            {
                return Ok(response);
            }
        }


        [HttpDelete("Remove/{id}")]

        public IActionResult RemoveStage(int id)
        {
            if (id > 0)
            {
                var response = _stageService.RemoveStages(id);

                if (!response.Success)
                {
                    return BadRequest(response);
                }
                else
                {
                    return Ok(response);
                }
            }
            else
            {
                return BadRequest("Please enter proper data.");
            }
        }

    }
}
