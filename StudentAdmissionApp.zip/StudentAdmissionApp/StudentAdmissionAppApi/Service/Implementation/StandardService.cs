﻿using StudentAdmissionAppApi.Data.Contract;
using StudentAdmissionAppApi.Data.Implementation;
using StudentAdmissionAppApi.Dtos;
using StudentAdmissionAppApi.Models;
using StudentAdmissionAppApi.Service.Contract;

namespace StudentAdmissionAppApi.Service.Implementation
{
    public class StandardService : IStandardService
    {
        private readonly IStandardRepository _standardRepository;

        public StandardService(IStandardRepository standardRepository)
        {
            _standardRepository = standardRepository;
        }

        public ServiceResponse<IEnumerable<StandardDto>> GetAllStandard(int page, int pageSize)
        {
            var response = new ServiceResponse<IEnumerable<StandardDto>>();
            var standards = _standardRepository.GetPaginatedStandards(page,pageSize);

            if (standards != null && standards.Any())
            {
                List<StandardDto> standardDtos = new List<StandardDto>();
                foreach (var standard in standards)
                {
                    standardDtos.Add(new StandardDto()
                    { 
                        StandardId = standard.StandardId,
                        StandardName = standard.StandardName,
                        ClassTeacherName = standard.ClassTeacherName 
                    });
                }
                response.Data = standardDtos;
            }
            else
            {
                response.Success = false;
                response.Message = "No record found!";
            }
            return response;
        }



        public ServiceResponse<IEnumerable<StandardDto>> GetAllStandardWithoutPage()
        {
            var response = new ServiceResponse<IEnumerable<StandardDto>>();
            var standards = _standardRepository.GetStandard();

            if (standards != null && standards.Any())
            {
                List<StandardDto> standardDtos = new List<StandardDto>();
                foreach (var standard in standards)
                {
                    standardDtos.Add(new StandardDto()
                    {
                        StandardId = standard.StandardId,
                        StageId = standard.StageId,
                        StageName = standard.Stage.StageName,
                        StageDescription = standard.Stage.StageDescription,
                        StandardName = standard.StandardName,
                        ClassTeacherName = standard.ClassTeacherName
                    });
                }
                response.Data = standardDtos;
            }
            else
            {
                response.Success = false;
                response.Message = "No record found!";
            }
            return response;
        }



        public ServiceResponse<StandardDto> GetStandardById(int id)
        {
            var response = new ServiceResponse<StandardDto>();

            var standard = _standardRepository.GetStandardById(id);

            var standardDto = new StandardDto()
            {
                StandardId = standard.StandardId,
                StandardName = standard.StandardName,
                StageId = standard.StageId,
                ClassTeacherName = standard.ClassTeacherName,
                Stages = new Stages()
                {
                    StageId = standard.Stage.StageId,
                    StageName = standard.Stage.StageName,
                    StageDescription = standard.Stage.StageDescription,
                }
            };

            response.Data = standardDto;
            return response;
        }






        public ServiceResponse<IEnumerable<StandardDto>> StandardByStageId(int id)
        {
            var response = new ServiceResponse<IEnumerable<StandardDto>>();
            var standards = _standardRepository.GetStandardByStageId(id);

            if (standards != null && standards.Any())
            {
                List<StandardDto> standardDtos = new List<StandardDto>();
                foreach (var standard in standards)
                {
                    standardDtos.Add(new StandardDto() { StandardId = standard.StandardId, StandardName = standard.StandardName, ClassTeacherName = standard.ClassTeacherName });
                }
                response.Data = standardDtos;
            }
            else
            {
                response.Success = false;
                response.Message = "No record found!";
            }
            return response;
        }



        public ServiceResponse<string> AddStandard(Standards standard)
        {
            var response = new ServiceResponse<string>();
            if (_standardRepository.StandardExists(standard.StandardId, standard.StandardName))
            {
                response.Success = false;
                response.Message = "Standard already exists";
                return response;
            }

            var result = _standardRepository.InsertStandard(standard);
            if (result)
            {
                response.Message = "Standards saved successfully.";
            }
            else
            {
                response.Success = false;
                response.Message = "Please try after sometime!";
            }

            return response;
        }



        public ServiceResponse<string> ModifyStandard(Standards standard)

        {
            var response = new ServiceResponse<string>();

            if (_standardRepository.StandardExists(standard.StandardId, standard.StandardName))

            {
                response.Success = false;
                response.Message = "Standard already exists.";
                return response;
            }

            var existingstandard = _standardRepository.GetStandardById(standard.StandardId);

            var result = false;

            if (existingstandard != null)

            {

                existingstandard.StandardName = standard.StandardName;
                existingstandard.ClassTeacherName = standard.ClassTeacherName;
                existingstandard.StageId = standard.StageId;

                result = _standardRepository.UpdateStandard(existingstandard);

            }

            if (result)
            {

                response.Message = "Standard updated successfully";
            }
            else
            {
                response.Success = false;
                response.Message = "Something went wrong.Try again later.";
            }


            return response;

        }


        public ServiceResponse<string> RemoveStandard(int id)
        {
            var response = new ServiceResponse<string>();
            var result = _standardRepository.DeleteStandard(id);
            if (result)
            {

                response.Message = "Standards deleted successfully.";
            }
            else
            {
                response.Success = false;
                response.Message = "Something went wrong, please try after sometimes.";
            }
            return response;
        }



    }
}
