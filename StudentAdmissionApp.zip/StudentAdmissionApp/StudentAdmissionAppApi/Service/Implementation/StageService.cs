﻿using StudentAdmissionAppApi.Data.Contract;
using StudentAdmissionAppApi.Data.Implementation;
using StudentAdmissionAppApi.Dtos;
using StudentAdmissionAppApi.Models;
using StudentAdmissionAppApi.Service.Contract;

namespace StudentAdmissionAppApi.Service.Implementation
{
    public class StageService : IStageService
    {
        private readonly IStageRepository _stageRepository;

        public StageService(IStageRepository stageRepository)
        {
            _stageRepository = stageRepository;
        }

        public ServiceResponse<IEnumerable<StageDto>> GetAllStages()
        {
            var response = new ServiceResponse<IEnumerable<StageDto>>();

            var stages = _stageRepository.GetStage();

            if (stages != null && stages.Any())
            {
                List<StageDto> stageDtos = new List<StageDto>();
                foreach (var stage in stages)
                {
                    stageDtos.Add(new StageDto() { StageId = stage.StageId, StageName = stage.StageName, StageDescription = stage.StageDescription });
                }
                response.Data = stageDtos;
            }

            else
            {
                response.Success = false;
                response.Message = "No record found!";
            }
            return response;
        }

        public ServiceResponse<StageDto> GetStageById(int id)
        {
            var response = new ServiceResponse<StageDto>();
            var existingStage = _stageRepository.GetStageById(id);
            if (existingStage != null)
            {
                var stage = new StageDto()
                {
                    StageId = existingStage.StageId,
                    StageName = existingStage.StageName,
                    StageDescription = existingStage.StageDescription,
                    
                };
                response.Data = stage;
            }
            else
            {
                response.Success = false;
                response.Message = "No record found!";
            }
            return response;
        }

        public ServiceResponse<string> AddStage(Stages stages)
        {
            var response = new ServiceResponse<string>();
            if (_stageRepository.GetAllStagesByNameAndDesc(stages.StageName))
            {
                response.Success = false;
                response.Message = "Stage already exists.";
                return response;

            }

            var result = _stageRepository.AddStage(stages);
            if (result)
            {
                response.Message = "Stage added successfully.";
            }
            else
            {
                response.Success = false;
                response.Message = "Something went wrong, please try after sometime.";
            }
            return response;
        }


        public ServiceResponse<string> UpdateStage(Stages stages)
        {
            var response = new ServiceResponse<string>();
            if (_stageRepository.GetAllStagesByNameAndDesc(stages.StageId, stages.StageName))
            {
                response.Success = false;
                response.Message = "Stage already exists.";
                return response;
            }

            var existingStage = _stageRepository.GetStageById(stages.StageId);
            var result = false;
            if (existingStage != null)
            {
                existingStage.StageName= stages.StageName;
                existingStage.StageDescription= stages.StageDescription;
                result = _stageRepository.UpdateStage(existingStage);
            }

            if (result)
            {
                response.Message = "Stage updated successfully.";
            }
            else
            {
                response.Success = false;
                response.Message = "Something went wrong, please try after sometime.";
            }

            return response;
        }


        public bool AlreadyExists(string name)
        {
            var result = false;
            var stages = _stageRepository.GetAllStagesByNameAndDesc(name);
            if (stages != null)
            {
                result = true;
            }
            return result;
        }

        public bool AlreadyExists(int stageId,string name)
        {
            var result = false;
            var stages = _stageRepository.GetAllStagesByNameAndDesc(stageId,name);
            if (stages != null)
            {
                result = true;
            }
            return result;
        }


        public ServiceResponse<string> RemoveStages(int id)
        {
            var response = new ServiceResponse<string>();
            var result = _stageRepository.DeleteStages(id);
            if (result)
            {
                response.Message = "Stage deleted successfully.";
            }
            else
            {
                response.Success = false;
                response.Message = "Something went wrong, please try after sometime.";
            }
            return response;
        }


    }
}
