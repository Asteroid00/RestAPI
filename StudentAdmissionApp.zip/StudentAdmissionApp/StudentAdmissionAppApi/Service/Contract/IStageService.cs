﻿using StudentAdmissionAppApi.Dtos;
using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Service.Contract
{
    public interface IStageService
    {
        public ServiceResponse<IEnumerable<StageDto>> GetAllStages();


        ServiceResponse<StageDto> GetStageById(int id);

        public ServiceResponse<string> AddStage(Stages stages);


        public ServiceResponse<string> UpdateStage(Stages stages);


        bool AlreadyExists(string name);

        bool AlreadyExists(int stageId, string name);

        ServiceResponse<string> RemoveStages(int id);

    }
}
