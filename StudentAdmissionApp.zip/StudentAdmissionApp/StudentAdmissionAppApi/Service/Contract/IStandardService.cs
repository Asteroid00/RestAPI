﻿using StudentAdmissionAppApi.Dtos;
using StudentAdmissionAppApi.Models;

namespace StudentAdmissionAppApi.Service.Contract
{
    public interface IStandardService
    {
        public ServiceResponse<IEnumerable<StandardDto>> GetAllStandard(int page, int pageSize);



        public ServiceResponse<IEnumerable<StandardDto>> GetAllStandardWithoutPage();



        public ServiceResponse<StandardDto> GetStandardById(int id);



        public ServiceResponse<IEnumerable<StandardDto>> StandardByStageId(int id);



        public ServiceResponse<string> AddStandard(Standards standard);



        public ServiceResponse<string> ModifyStandard(Standards standard);


        public ServiceResponse<string> RemoveStandard(int id);
    }
}
