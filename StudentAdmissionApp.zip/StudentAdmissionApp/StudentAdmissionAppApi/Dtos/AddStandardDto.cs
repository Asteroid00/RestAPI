﻿using System.ComponentModel.DataAnnotations;

namespace StudentAdmissionAppApi.Dtos
{
    public class AddStandardDto
    {
        [Required(ErrorMessage = "Standard name is required.")]
        [StringLength(50)]
        public string StandardName { get; set; }

        [Required(ErrorMessage = "Class teacher name is required.")]
        public string ClassTeacherName { get; set; }

        [Required(ErrorMessage = "Standard stage is required.")]
        public int StageId { get; set; }


    }
}
