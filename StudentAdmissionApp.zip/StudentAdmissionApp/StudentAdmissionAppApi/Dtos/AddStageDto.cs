﻿namespace StudentAdmissionAppApi.Dtos
{
    public class AddStageDto
    {
       
        public string StageName { get; set; }
        public string StageDescription { get; set; }
    }
}
