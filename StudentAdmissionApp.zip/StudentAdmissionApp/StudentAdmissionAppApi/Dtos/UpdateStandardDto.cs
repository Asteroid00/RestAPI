﻿using System.ComponentModel.DataAnnotations;

namespace StudentAdmissionAppApi.Dtos
{
    public class UpdateStandardDto
    {
        [Required(ErrorMessage = "Standard id is required.")]
        public int StandardId { get; set; }
        [Required(ErrorMessage = "Standard name is required.")]
        public string StandardName { get; set; }
        [Required(ErrorMessage = "Class teacher name is required.")]
        public string ClassTeacherName { get; set; }
        [Required(ErrorMessage = "Stage id is required.")]
        public int StageId { get; set; }
    }
}
