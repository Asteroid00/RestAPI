﻿using System.ComponentModel.DataAnnotations;

namespace StudentAdmissionAppApi.Dtos
{
    public class UpdateStageDto
    {
       
        public int StageId { get; set; }


        [Required(ErrorMessage = "Stage name is required.")]
        public string StageName { get; set; }


        [Required(ErrorMessage = "Stage discription is required.")]
        public string StageDescription { get; set; }
    }
}
