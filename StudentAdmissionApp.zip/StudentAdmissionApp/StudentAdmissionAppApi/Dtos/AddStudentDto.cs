﻿using System.ComponentModel.DataAnnotations;

namespace StudentAdmissionAppApi.Dtos
{
    public class AddStudentDto
    {
        [Required(ErrorMessage = "State id is required.")]
        public int StageId { get; set; }
        [Required(ErrorMessage = "Standard id is required.")]
        public int StandardId { get; set; }
        [Required(ErrorMessage = "Student name is required.")]
        public string StudentName { get; set; }
        [Required(ErrorMessage = "Student email is required.")]
        public string StudentEmail { get; set; }
        public bool IsPhysicallyDisabled { get; set; }
        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Date of application is required.")]
        public DateTime DateOfApplication { get; set; }
        public string Image { get; set; }
        public decimal? Maths { get; set; }
        public decimal? Science { get; set; }
        public decimal? SocialStudies { get; set; }
        public decimal? Hindi { get; set; }
        public decimal? English { get; set; }
        public decimal? Chemistry { get; set; }
        public decimal? Biology { get; set; }
        public decimal? Physics { get; set; }
    }
}
