﻿namespace StudentAdmissionAppApi.Dtos
{
    public class StageDto
    {
        public int StageId { get; set; }
        public string StageName { get; set; }
        public string StageDescription { get; set; }
    }
}
