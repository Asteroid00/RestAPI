﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace StudentAdmissionMVC.ViewModels
{
    public class AddStandardViewModel
    {
        [Required(ErrorMessage = "Standard name is required.")]
        [DisplayName("Standard name")]
        public string StandardName { get; set; }

        [Required(ErrorMessage = "Teacher name is required.")]
        [DisplayName("Teacher name")]
        public string ClassTeacherName { get; set; }

        [Required(ErrorMessage = "Stage is required.")]
        [DisplayName("Stage")]
        public int StageId { get; set; }

        public List<StandardStageViewModel>? Stages { get; set; }

    }
}
