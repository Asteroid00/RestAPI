﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace StudentAdmissionMVC.ViewModels
{
    public class UpdateStudentViewModel
    {
        [Required(ErrorMessage = "Student id is required.")]
        public int StudentId { get; set; }
        [Required(ErrorMessage = "Stage id is required.")]
        public int StageId { get; set; }
        [Required(ErrorMessage = "Standard id is required.")]
        public int StandardId { get; set; }
        [Required(ErrorMessage = "Student name is required.")]
        public string StudentName { get; set; }
        [Required(ErrorMessage = "Student email address is required.")]
        public string StudentEmail { get; set; }
        [Required(ErrorMessage = "Student id is required.")]
        public bool IsPhysicallyDisabled { get; set; } = false;
        [Required(ErrorMessage = "Gender is required.")]
        public string Gender { get; set; }
        [Required(ErrorMessage = "Date of application is required.")]
        public DateTime DateOfApplication { get; set; }
        public string Image { get; set; } = string.Empty;

        [Required(ErrorMessage = "File is required.")]
        public IFormFile File { get; set; }

        public decimal? Maths { get; set; }
        public decimal? Science { get; set; }
        public decimal? SocialStudies { get; set; }
        public decimal? Hindi { get; set; }
        public decimal? English { get; set; }
        public decimal? Chemistry { get; set; }
        public decimal? Biology { get; set; }
        public decimal? Physics { get; set; }
        public decimal? TotalMarks { get; set; }
        public decimal? Percentages { get; set; }
        public bool IsAdmisisonConfirmed { get; set; }

        public List<StandardStageViewModel>? Stage { get; set; }
        public List<StandardViewModel>? Standard { get; set; }
    }
}
