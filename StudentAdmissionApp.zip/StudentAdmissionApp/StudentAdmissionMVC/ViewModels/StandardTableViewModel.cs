﻿namespace StudentAdmissionMVC.ViewModels
{
    public class StandardTableViewModel
    {
        public int StandardId { get; set; }

        public string StandardName { get; set; }

        public string classTeacherName { get; set; }

        public int stageId { get; set; }

        public string stageName { get; set; }

        public string stageDescription { get; set; }

    }
}
