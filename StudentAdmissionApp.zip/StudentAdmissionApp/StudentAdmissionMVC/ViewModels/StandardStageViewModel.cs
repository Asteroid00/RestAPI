﻿namespace StudentAdmissionMVC.ViewModels
{
    public class StandardStageViewModel
    {
        public int StageId { get; set; }

        public string StageName { get; set; }

        public string StageDescription { get; set; }
    }
}
