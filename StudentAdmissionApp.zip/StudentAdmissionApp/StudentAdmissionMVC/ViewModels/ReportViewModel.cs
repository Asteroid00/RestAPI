﻿namespace StudentAdmissionMVC.ViewModels
{
    public class ReportViewModel
    {
        public string stageName { get; set; }

        public string standardName { get; set; }

        public int totalStudent { get; set; }
    }
}
