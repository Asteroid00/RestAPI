﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace StudentAdmissionMVC.ViewModels
{
    public class UpdateStageViewModel
    {
        public int StageId { get; set; }

        [Required(ErrorMessage = "Stage name is required.")]
        [DisplayName("Stage name")]
        public string StageName { get; set; }

        [Required(ErrorMessage = "Stage description is required.")]
        [DisplayName("Stage description")]
        public string StageDescription { get; set; }
    }
}
