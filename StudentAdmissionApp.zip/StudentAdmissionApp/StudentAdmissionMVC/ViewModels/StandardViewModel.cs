﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace StudentAdmissionMVC.ViewModels
{
    public class StandardViewModel
    {

        public int StandardId { get; set; }
        public string StandardName { get; set; } = "";
        public string ClassTeacherName { get; set; }
        public int StageId { get; set; }

        public StandardStageViewModel Stages { get; set; }
    }
}
