﻿$(document).ready(function () {

    $('#stageForm').submit(function (e) {
        e.preventDefault()

        const jwtToken = getCookie('jwtToken');
        if (!jwtToken) {
            window.location.href = '/auth/login';
            return;
        }

        if (ValidateStageForm()) {
            let stageName = $('#StageName').val().trim();
            let stageDescription = $('#StageDescription').val().trim();

            var requestData = {
                stageName: stageName,
                stageDescription: stageDescription
            };
            //$('#loader').show();
            $.ajax({
                url: "http://localhost:5101/api/Stage/AddStage",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(requestData),
                headers: {
                    'Authorization': 'Bearer ' + jwtToken
                },
                success: function (response) {
                    ShowMessage(response.message);
                },
                error: function (xhr, status, error) {
                    // Check if there is a responseText available
                    if (xhr.responseText) {
                        try {
                            // Parse the responseText into a JavaScript object
                            var errorResponse = JSON.parse(xhr.responseText);

                            // Check the properties of the errorResponse object
                            if (errorResponse && errorResponse.message) {
                                // Display the error message to the user
                                alert('Error: ' + errorResponse.message);
                            } else {
                                // Display a generic error message
                                alert('An error occurred. Please try again.');
                            }
                        } catch (parseError) {
                            console.error('Error parsing response:', parseError);
                            alert('An error occurred. Please try again.');
                        }
                    } else {
                        // Display a generic error message if no responseText is available
                        alert('An unexpected error occurred. Please try again.');
                    }
                },
                // complete: function () { 
                //     $('#loader').hide();
                // }
            });
        }
    });

});

function getCookie(name) {
    const cookieValue = document.cookie
        .split('; ')
        .find(cookie => cookie.startsWith(name + "="))
        ?.split('=')[1];
    return cookieValue ? decodeURIComponent(cookieValue) : null;
}
function ValidateStageForm() {
    //e.preventDefault()//prevent default form submission
    let stageName = $('#StageName').val().trim();
    let stageDescription = $('#StageDescription').val().trim();
    $('#validationSummary').empty().hide();
    let isValid = true;
    if (stageName.length === 0) {
        $('#validationSummary').append('<p>Stage name is required.</p>');
        isValid = false;
    }
    if (stageDescription.length === 0) {
        $('#validationSummary').append('<p>Stage description is required.</p>');
        isValid = false;
    }

    if (!isValid) {
        $('#validationSummary').show();
    }
    return isValid;

}
function ShowMessage(message) {
    // Get the message container
    var messageContainer = document.getElementById('messageContainer');

    // Display success message
    messageContainer.textContent = message;
    messageContainer.style.backgroundColor = '#4CAF50';
    messageContainer.style.opacity = '1';

    // Hide the message after 3 seconds (3000 milliseconds)
    setTimeout(function () {
        messageContainer.style.opacity = '0';
    }, 1500);

    // Redirect to index page after a short delay (optional)
    setTimeout(function () {
        window.location.href = '/StageAjax/Index';
    }, 1000); // Redirect after 3.5 seconds (3500 milliseconds)
}