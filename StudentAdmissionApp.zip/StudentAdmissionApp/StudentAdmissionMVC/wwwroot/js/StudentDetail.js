﻿



$(document).ready(function () {
    GetStudentDetails();

});


function GetStudentDetails() {
    var currentUrl = window.location.href;
    var id = currentUrl.substring(currentUrl.lastIndexOf("/") + 1);

    $.ajax({
        url: "http://localhost:5101/api/Student/GetStudentById/" + id,
        type: 'GET',
        dataType: 'json',
        success: function (response) {
            if (response.success) {
                if (response.data.isPhysicallyDisabled == "true") {
                    response.data.isPhysicallyDisabled = "Yes";
                }
                else {
                    response.data.isPhysicallyDisabled = "No";
                }
                
                $('#StudentId').val(response.data.studentId);
                $('#StudentName').html(response.data.studentName);
                $('#StudentEmail').html(response.data.studentEmail);
                $('#IsPhysicallyDisabled').html(response.data.isPhysicallyDisabled);
                $('#Gender').html(response.data.gender);
                $('#DateOfApplication').html(response.data.dateOfApplication);

            }
        },
        error: function (xhr, status, error) {
            // Check if there is a responseText available
            if (xhr.responseText) {
                try {
                    // Parse the responseText into a JavaScript object
                    var errorResponse = JSON.parse(xhr.responseText);

                    // Check the properties of the errorResponse object
                    if (errorResponse && errorResponse.message) {
                        // Display the error message to the user
                        alert('Error: ' + errorResponse.message);
                    } else {
                        // Display a generic error message
                        alert('An error occurred. Please try again.');
                    }
                } catch (parseError) {
                    console.error('Error parsing response:', parseError);
                    alert('An error occurred. Please try again.');
                }
            } else {
                // Display a generic error message if no responseText is available
                alert('An unexpected error occurred. Please try again.');
            }
        },

    });

}



