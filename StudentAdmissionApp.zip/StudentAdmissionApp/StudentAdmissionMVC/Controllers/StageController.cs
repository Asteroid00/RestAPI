﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentAdmissionMVC.Infrastructure;
using StudentAdmissionMVC.ViewModels;

namespace StudentAdmissionMVC.Controllers
{
    
    public class StageController : Controller
    {
        private readonly IHttpClientService _httpClientService;
        private readonly IConfiguration _configuration;
        private string endPoint;

        public StageController(IHttpClientService httpClientService, IConfiguration configuration)
        {
            _httpClientService = httpClientService;
            _configuration = configuration;
            endPoint = _configuration["EndPoint:CivicaApi"];
        }

        public IActionResult Index()
        {
            ServiceResponse<IEnumerable<StandardStageViewModel>> response = new ServiceResponse<IEnumerable<StandardStageViewModel>>();

            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StandardStageViewModel>>>
                ($"{endPoint}Stage/GetAll", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return View(response.Data);
            }

            return View(new List<StandardStageViewModel>());
        }

        [Authorize]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Create(AddStageViewmodel viewModel)
        {
            if (ModelState.IsValid)
            {

                string apiUrl = $"{endPoint}Stage/AddStage";
                var response = _httpClientService.PostHttpResponseMessage<AddStageViewmodel>(apiUrl, viewModel, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;

                    return RedirectToAction("Index");

                }
                else
                {
                    string errorMessage = response.Content.ReadAsStringAsync().Result;
                    var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorMessage);
                    if (errorMessage != null)
                    {
                        TempData["errorMessage"] = errorResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                    }

                }
            }
            return View(viewModel);
        }
        [HttpGet]
        public IActionResult Details(int id)
        {

            var apiUrl = $"{endPoint}Stage/GetStageById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateStageViewModel>(apiUrl, HttpContext.Request);

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStageViewModel>>(data);

                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }

            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStageViewModel>>(errorData);

                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                }
                return RedirectToAction("Index");
            }


        }



        [HttpGet]
        [Authorize]
        public IActionResult Edit(int id)
        {

            var apiUrl = $"{endPoint}Stage/GetStageById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateStageViewModel>(apiUrl, HttpContext.Request);

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStageViewModel>>(data);

                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }

            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStageViewModel>>(errorData);

                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                }
                return RedirectToAction("Index");
            }


        }

        [HttpPost]
        public IActionResult Edit(UpdateStageViewModel updateCategory)
        {
            if (ModelState.IsValid)
            {

                var apiUrl = $"{endPoint}Stage/UpdateStage";
                HttpResponseMessage response = _httpClientService.PutHttpResponseMessage(apiUrl, updateCategory, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;

                    return RedirectToAction("Index");


                }
                else
                {
                    string errorMessage = response.Content.ReadAsStringAsync().Result;
                    var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorMessage);
                    if (errorMessage != null)
                    {
                        TempData["errorMessage"] = errorResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                    }

                }
            }
            return View(updateCategory);
        }

        [HttpGet]
        [Authorize]
        public IActionResult Delete(int id)
        {

            var apiUrl = $"{endPoint}Stage/GetStageById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<StandardStageViewModel>(apiUrl, HttpContext.Request);

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<StandardStageViewModel>>(data);

                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }

            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<StandardStageViewModel>>(errorData);

                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                }
                return RedirectToAction("Index");
            }
        }

        public IActionResult DeleteConfirmed(int stageid)
        {

            var apiUrl = $"{endPoint}Stage/Remove/" + stageid;

            var response = _httpClientService.ExecuteApiRequest<ServiceResponse<string>>($"{apiUrl}", HttpMethod.Delete, HttpContext.Request);
            if (response.Success)
            {

                TempData["successMessage"] = response.Message;

                return RedirectToAction("Index");


            }
            else
            {

                TempData["errorMessage"] = response.Message;
                return RedirectToAction("Index");
            }

        }
    }
}
