﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentAdmissionMVC.Infrastructure;
using StudentAdmissionMVC.ViewModels;

namespace StudentAdmissionMVC.Controllers
{
   
    public class StudentController : Controller
    {
        private readonly IHttpClientService _httpClientService;
        private readonly IConfiguration _configuration;
        private string endPoint;

        public StudentController(IHttpClientService httpClientService, IConfiguration configuration)
        {
            _httpClientService = httpClientService;
            _configuration = configuration;
            endPoint = _configuration["EndPoint:CivicaApi"];
        }

        [HttpGet]

        public IActionResult Index()
        {
            ServiceResponse<IEnumerable<StudentViewModel>> response = new ServiceResponse<IEnumerable<StudentViewModel>>();

            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StudentViewModel>>>
                ($"{endPoint}Student/GetAllStudents", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return View(response.Data);
            }

            return View(new List<StudentViewModel>());
        }

        [HttpGet]
        [Authorize]
        public IActionResult Create()
        {
            AddStudentViewModel studentViewModel = new AddStudentViewModel();
            studentViewModel.Stage = GetAllStages();
            studentViewModel.Standard = GetStandards();
            return View(studentViewModel);
        }

        [HttpPost]
        public IActionResult Create(AddStudentViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                string apiUrl = $"{endPoint}Student/AddStudent";
                var response = _httpClientService.PostHttpResponseMessage(apiUrl, viewModel, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;

                    return RedirectToAction("Index");

                }
                else
                {
                    string errorMessage = response.Content.ReadAsStringAsync().Result;
                    var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorMessage);
                    if (errorMessage != null)
                    {
                        TempData["errorMessage"] = errorResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                    }

                }
                return RedirectToAction("Index");
            }
            viewModel.Stage = GetAllStages();
            viewModel.Standard = GetStandards();
            return View(viewModel);
        }


        [HttpGet]
        private List<StandardStageViewModel> GetAllStages()
        {
            ServiceResponse<IEnumerable<StandardStageViewModel>> response = new ServiceResponse<IEnumerable<StandardStageViewModel>>();

            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StandardStageViewModel>>>
                ($"{endPoint}Stage/GetAll", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return response.Data.ToList();
            }

            return new List<StandardStageViewModel>();
        }





        [HttpGet]
        [Authorize]
        public IActionResult Edit(int id)
        {

            var apiUrl = $"{endPoint}Student/GetStudentById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<AddStudentViewModel>(apiUrl, HttpContext.Request);


            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<AddStudentViewModel>>(data);
                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    AddStudentViewModel viewModel = serviceResponse.Data;
                    viewModel.Stage = GetAllStages();
                    viewModel.Standard = GetStandardById(viewModel.StageId);
                    return View(viewModel);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<AddStudentViewModel>>(errorData);
                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong.Please try after sometime.";
                }
                return RedirectToAction("Index");
            }
        }

        [HttpPost]
        public IActionResult Edit(AddStudentViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var apiUrl = $"{endPoint}Student/UpdateStudent";
                HttpResponseMessage response = _httpClientService.PutHttpResponseMessage(apiUrl, viewModel, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
                else
                {
                    string errorData = response.Content.ReadAsStringAsync().Result;
                    var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorData);
                    if (errorResponse != null)
                    {
                        TempData["errorMessage"] = errorResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong try after some time";
                        return RedirectToAction("Index");
                    }
                }
            }
            return View(viewModel);
        }





        


        [HttpGet]

        public IActionResult Details(int id)
        {
            var apiUrl = $"{endPoint}Student/GetStudentById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateStudentViewModel>(apiUrl, HttpContext.Request);
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStudentViewModel>>(data);
                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["ErrorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStudentViewModel>>(errorData);
                if (errorResponse != null)
                {
                    TempData["ErrorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["ErrorMessage"] = "Something went wrong.Please try after sometime.";
                }
                return RedirectToAction("Index");
            }

        }


        private List<StandardViewModel> GetStandards()
        {
            ServiceResponse<IEnumerable<StandardViewModel>> response = new ServiceResponse<IEnumerable<StandardViewModel>>();
            string endPoint = _configuration["EndPoint:CivicaApi"];
            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StandardViewModel>>>
                ($"{endPoint}Standard/GetAllStandardWithoutPage", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return response.Data.ToList();
            }
            return new List<StandardViewModel>();
        }

        private List<StandardViewModel> GetStandardById(int id)
        {
            ServiceResponse<IEnumerable<StandardViewModel>> response = new ServiceResponse<IEnumerable<StandardViewModel>>();
            string endPoint = _configuration["EndPoint:CivicaApi"];
            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StandardViewModel>>>
                ($"{endPoint}Standard/GetAllStandardByStageId/" + id, HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return response.Data.ToList();
            }
            return new List<StandardViewModel>();
        }

    }
}
