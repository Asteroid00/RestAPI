﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using StudentAdmissionMVC.Infrastructure;
using StudentAdmissionMVC.ViewModels;

namespace StudentAdmissionMVC.Controllers
{
    
    public class StandardController : Controller
    {
        private readonly IHttpClientService _httpClientService;
        private readonly IConfiguration _configuration;
        private string endPoint;

        public StandardController(IHttpClientService httpClientService, IConfiguration configuration)
        {
            _httpClientService = httpClientService;
            _configuration = configuration;
            endPoint = _configuration["EndPoint:CivicaApi"];
        }

        [HttpGet]
        public IActionResult Index()
        {
            ServiceResponse<IEnumerable<StandardTableViewModel>> response = new ServiceResponse<IEnumerable<StandardTableViewModel>>();

            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StandardTableViewModel>>>
                ($"{endPoint}Standard/GetAllStandardWithoutPage", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return View(response.Data);
            }

            return View(new List<StandardTableViewModel>());
        }




        [HttpGet]
        [Authorize]
        public IActionResult Create()
        {
            AddStandardViewModel standardViewModel = new AddStandardViewModel();
            standardViewModel.Stages = GetStages();
            return View(standardViewModel);
        }

        [HttpPost]
        public IActionResult Create(AddStandardViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                var apiUrl = $"{endPoint}Standard/AddStandard";
                var response = _httpClientService.PostHttpResponseMessage(apiUrl, viewModel, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<AddStandardViewModel>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
                else
                {
                    string errorResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<AddStandardViewModel>>(errorResponse);
                    if (errorResponse != null)
                    {
                        TempData["errorMessage"] = serviceResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime";
                    }
                }
            }
            viewModel.Stages = GetStages();
            return View(viewModel);
        }





        private List<StandardStageViewModel> GetStages()
        {
            ServiceResponse<IEnumerable<StandardStageViewModel>> response = new ServiceResponse<IEnumerable<StandardStageViewModel>>();

            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<StandardStageViewModel>>>
                ($"{endPoint}Stage/GetAll", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return response.Data.ToList();
            }

            return new List<StandardStageViewModel>();
        }






        public IActionResult Details(int id)
        {

            var apiUrl = $"{endPoint}Standard/GetStandardById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateStandardViewModel>(apiUrl, HttpContext.Request);
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStandardViewModel>>(data);
                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStandardViewModel>>(errorData);
                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime";
                }
                return RedirectToAction("Index");
            }
        }
        [HttpGet]
        [Authorize]
        public ActionResult Edit(int id)
        {

            var apiUrl = $"{endPoint}Standard/GetStandardById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateStandardViewModel>(apiUrl, HttpContext.Request);
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStandardViewModel>>(data);
                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {

                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStandardViewModel>>(errorData);
                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime";
                }
                return RedirectToAction("Index");
            }

        }
        [HttpPost]
        public IActionResult Edit(UpdateStandardViewModel updateStandard)
        {
            if (ModelState.IsValid)
            {

                var apiUrl = $"{endPoint}Standard/ModifyStandard";
                HttpResponseMessage response = _httpClientService.PutHttpResponseMessage(apiUrl, updateStandard, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var ServiceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = ServiceResponse.Message;
                    return RedirectToAction("Index");
                }
                else
                {
                    string errorResponse = response.Content.ReadAsStringAsync().Result;
                    var ServiceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorResponse);
                    if (errorResponse != null)
                    {
                        TempData["errorMessage"] = ServiceResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime";
                    }
                    return RedirectToAction("Index");
                }

            }
            return View(updateStandard);
        }

        [HttpGet]
        [Authorize]
        public IActionResult Delete(int id)
        {

            var apiUrl = $"{endPoint}Standard/GetStandardById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateStandardViewModel>(apiUrl, HttpContext.Request);
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStandardViewModel>>(data);
                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }
            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateStandardViewModel>>(errorData);
                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime";
                }
                return RedirectToAction("Index");
            }
        }
        [HttpPost]
        public IActionResult DeleteConfirmed(int standardId)
        {
            var apiUrl = $"{endPoint}Standard/Delete/" + standardId;
            var response = _httpClientService.ExecuteApiRequest<ServiceResponse<string>>($"{apiUrl}", HttpMethod.Delete, HttpContext.Request);


            if (response.Success)
            {

                TempData["successMessage"] = response.Message;
                return RedirectToAction("Index");
            }
            else
            {
                TempData["errorMessage"] = response.Message;
                return RedirectToAction("Index");
            }


        }


    }
}
