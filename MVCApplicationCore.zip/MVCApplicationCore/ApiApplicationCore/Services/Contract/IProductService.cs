﻿using ApiApplicationCore.Data.Contract;
using ApiApplicationCore.Dtos;
using ApiApplicationCore.Models;

namespace ApiApplicationCore.Services.Contract
{
    public interface IProductService
    {

        public ServiceResponse<string> AddProduct(Product product);

        public ServiceResponse<string> UpdateProduct(Product product);

        public ServiceResponse<string> DeleteProduct(int id);

        public ServiceResponse<IEnumerable<ProductDto>> GetAllProducts();

        public ServiceResponse<ProductDto> GetProductById(int id);
    }
}
