﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Moq;
using MVCApplicationCore.Controllers;
using MVCApplicationCore.Models;
using MVCApplicationCore.Services.Contract;
using MVCApplicationCore.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace MVCApplicationCoreTests.Controllers
{
    public class ProductControllerTests
    {
        [Fact]
        public void Index_ReturnViewWithProducts_WhenProductsExists()
        {
            var products = new List<Product>
            {
                new Product  { ProductId = 1 , ProductName="Product 1" , ProductDescription="Description 1" },
                new Product  { ProductId = 2 , ProductName="Product 2" , ProductDescription="Description 2" },
                new Product  { ProductId = 3 , ProductName="Product 3" , ProductDescription="Description 3" }
            };

            var mockProductService = new Mock<IProductService>();
            var mockCategoryService = new Mock<ICategoryService>();
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object);
            mockProductService.Setup(c => c.GetAllProducts()).Returns(products);

            //Act
            var actual = target.Index() as ViewResult;


            //Assert
            Assert.NotNull(actual);
            Assert.NotNull(actual.Model);
            Assert.Equal(products, actual.Model);
            mockProductService.Verify(c => c.GetAllProducts(), Times.Once);
        }


        [Fact]
        public void Index_ReturnViewWithEmptyList_WhenNoProductsExist()
        {
            //Arrange
            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object);
            mockProductService.Setup(c => c.GetAllProducts()).Returns(new List<Product>());

            //Act
            var actual = target.Index() as ViewResult;

            //Assert
            Assert.NotNull(actual);
           
            Assert.NotNull(actual.Model);
            Assert.Equal(new List<Product>(), actual.Model);
            mockProductService.Verify(c => c.GetAllProducts(), Times.Once);
        }

        [Fact]
        public void Create_ReturnView()
        {
            //Arrenge
            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object);

            //Act
            var actual = target.Create() as ViewResult;

            //Assert
            Assert.NotNull(actual);
        }
        

        [Fact]
        public void Create_ReturnView_withModelStateIsInValid()
        {
            //Arrenge
            var productViewModel = new ProductViewModel { ProductName = "Product 1" };
            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object);

            target.ModelState.AddModelError("ProductName", "Product name is required.");


            //Act
            var actual = target.Create(productViewModel) as ViewResult;


            //Assert
            Assert.NotNull(actual);
            Assert.Equal(productViewModel, actual.Model);
            Assert.False(target.ModelState.IsValid);
        }


        [Fact]
        public void Create_ReturnsRedirectToActionResult_WhenProductAddedSuccessfully()
        {
            var productViewModel = new ProductViewModel { ProductName = "Product 1", ProductDescription = "Description 1" };
            var product = new Product()
            {
                ProductName = productViewModel.ProductName,
                ProductDescription = productViewModel.ProductDescription,
            };
            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var mockDataProvider = new Mock<ITempDataProvider>();
            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockDataProvider.Object);
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object)
            {
                TempData = tempData,
            };
            mockProductService.Setup(c => c.AddProduct(It.IsAny<Product>())).Returns("Product saved successfully.");


            //Act
            var actual = target.Create(productViewModel) as RedirectToActionResult;


            //Assert
            Assert.NotNull(actual);
            Assert.True(target.ModelState.IsValid);
            Assert.Equal("Index", actual.ActionName);
            mockProductService.Verify(c => c.AddProduct(It.IsAny<Product>()), Times.Once);
        }


        [Theory]
        [InlineData("Product already exists.")]
        [InlineData("Something went wrong.Please try after sometime.")]
        public void Create_SetErrorMessageInTempData_WhenCreateFails(string errorMessage)
        {
            //Arrange
            var productViewModel = new ProductViewModel { ProductName = "Product 1", ProductDescription = "Description 1" };
            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var mockDataProvider = new Mock<ITempDataProvider>();
            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockDataProvider.Object);
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object)
            {
                TempData = tempData,
            };
            mockProductService.Setup(c => c.AddProduct(It.IsAny<Product>())).Returns(errorMessage);




            //Act
            var actual = target.Create(productViewModel) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            Assert.True(target.ModelState.IsValid);
            Assert.Equal(productViewModel, actual.Model);
            mockProductService.Verify(c => c.AddProduct(It.IsAny<Product>()), Times.Once);
        }


        [Fact]
        public void Details_ReturnsNotFound_whenProductNotFound()
        {
            //Arrenge
            var mockcategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            mockProductService.Setup(c => c.GetProductById(1)).Returns<Product>(null);
            var target = new ProductController(mockProductService.Object,mockcategoryService.Object);

            //Act
            var actual = target.Details(1) as NotFoundResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.NotFound, actual.StatusCode);
            mockProductService.Verify(c => c.GetProductById(1), Times.Once);
        }

        [Fact]
        public void Details_ReturnsView_WhenCategoryFound()
        {
            //Arrenge
            var productId = 1;
            var product = new Product()
            {
                ProductId = productId,
                ProductName = "Product 1",
                ProductDescription = "Description 1"
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object);
            mockProductService.Setup(c => c.GetProductById(productId)).Returns(product);

            //Act
            var actual = target.Details(productId) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            mockProductService.Verify(c => c.GetProductById(productId), Times.Once);


        }





        [Fact]
        public void Delete_ReturnsNotFound_whenProductNotFound()
        {
            //Arrenge
            var mockcategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            mockProductService.Setup(c => c.GetProductById(1)).Returns<Product>(null);
            var target = new ProductController(mockProductService.Object,mockcategoryService.Object);

            //Act
            var actual = target.Delete(1) as NotFoundResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.NotFound, actual.StatusCode);
            mockProductService.Verify(c => c.GetProductById(1), Times.Once);
        }

        [Fact]
        public void Delete_ReturnsView_WhenProductFound()
        {
            //Arrenge
            var productId = 1;
            var product = new Product()
            {
                ProductId = productId,
                ProductName = "Product 1",
                ProductDescription = "Description 1"
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            var target = new ProductController(mockProductService.Object,mockCategoryService.Object);
            mockProductService.Setup(c => c.GetProductById(productId)).Returns(product);

            //Act
            var actual = target.Delete(productId) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            mockProductService.Verify(c => c.GetProductById(productId), Times.Once);
        }

        [Theory]
        [InlineData("Product deleted successfully.")]
        [InlineData("Something went wrong.Please try after sometime.")]
        public void DeleteConfirmed(string errorMessage)
        {

            var mockCategoryService = new Mock<ICategoryService>();
            var mockProductService = new Mock<IProductService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            mockProductService.Setup(c => c.DeleteProduct(1)).Returns(errorMessage);


            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockTempDataProvider.Object);

            var target = new ProductController(mockProductService.Object,mockCategoryService.Object)
            {
                TempData = tempData
            };


            //Act
            var actual = target.DeleteConfirmed(1) as RedirectToActionResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal("Index", actual.ActionName);
            mockCategoryService.Verify(c => c.RemoveCategory(1), Times.Once);
        }






    }
}
