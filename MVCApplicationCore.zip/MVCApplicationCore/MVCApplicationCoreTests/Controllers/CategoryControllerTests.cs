﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Moq;
using MVCApplicationCore.Controllers;
using MVCApplicationCore.Models;
using MVCApplicationCore.Services.Contract;
using MVCApplicationCore.Services.Implementation;
using MVCApplicationCore.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Xunit.Sdk;

namespace MVCApplicationCoreTests.Controllers
{
    
    public class CategoryControllerTests
    {
        [Fact]
        public void Index1_ReturnViewWithCategories_WhenCategoryExists()
        {
            //Arrange
            var categories = new List<Category>
            {
                new Category{CategoryId = 1 , Name="Category 1"},
                new Category{CategoryId = 2 , Name="Category 2"},
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var target = new CategoryController(mockCategoryService.Object);
            mockCategoryService.Setup(c => c.GetCategories()).Returns(categories);

            //Act
            var actual = target.Index1() as ViewResult;


            //Assert
            Assert.NotNull(actual);
            Assert.Equal("CategoryList", actual.ViewName);
            Assert.NotNull(actual.Model);
            Assert.Equal(categories, actual.Model);
            mockCategoryService.Verify(c => c.GetCategories(),Times.Once);
        }

        [Fact]
        public void Index1_ReturnViewWithEmptyList_WhenNoCategoriesExist()
        {
            //Arrange
            var mockCategoryService = new Mock<ICategoryService>();
            var target = new CategoryController(mockCategoryService.Object);
            mockCategoryService.Setup(c => c.GetCategories()).Returns(new List<Category>());

            //Act
            var actual = target.Index1() as ViewResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal("CategoryList",actual.ViewName);
            Assert.NotNull(actual.Model);
            Assert.Equal(new List<Category>(), actual.Model);
            mockCategoryService.Verify(c => c.GetCategories(), Times.Once);
        }

        [Fact]
        public void Index1_ReturnViewWithoutData()
        {
            //Arrange
            List<Category> categories = new List<Category>();
            var mockCategoryService = new Mock<ICategoryService>();
            var target = new CategoryController(mockCategoryService.Object);
            mockCategoryService.Setup(c => c.GetCategories()).Returns((List<Category>)null);

            //Act
            var actual = target.Index1() as ViewResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal("CategoryList", actual.ViewName);
            Assert.NotNull(actual.Model);
            Assert.Equal(categories, actual.Model);
            mockCategoryService.Verify(c => c.GetCategories(), Times.Once);
        }

        [Fact]

        public void Create_ReturnView()
        {
            //Arrenge
            var mockCategoryService  = new Mock<ICategoryService>();
            var target = new CategoryController(mockCategoryService.Object);

            //Act
            var actual = target.Create() as ViewResult;

            //Assert
            Assert.NotNull(actual);

        }

        [Fact]
        public void Create_ReturnView_withModelStateIsInValid()
        {
            //Arrenge
            var categoryViewModel = new CategoryViewModel { Description="Category 1" };
            var mockCategoryService = new Mock<ICategoryService>();
            var target = new CategoryController(mockCategoryService.Object);

            target.ModelState.AddModelError("Name", "Name is required.");


            //Act
            var actual = target.Create(categoryViewModel) as ViewResult;


            //Assert
            Assert.NotNull(actual);
            Assert.Equal(categoryViewModel,actual.Model);
            Assert.False(target.ModelState.IsValid);
        }

        [Fact]
        public void Create_ReturnsRedirectToActionResult_WhenCategoryAddedSuccessfully()
        {
            //Arrenge
            var categoryViewModel = new CategoryViewModel {Name="Category 1", Description = "Description 1" };
            var category = new Category()
            {
                Name = categoryViewModel.Name,
                Description = categoryViewModel.Description, 
            };
            var mockCategoryService = new Mock<ICategoryService>();
            var mockDataProvider = new Mock<ITempDataProvider>();
            var tempData = new TempDataDictionary(new DefaultHttpContext(),mockDataProvider.Object);
            var target = new CategoryController(mockCategoryService.Object)
            {
                TempData = tempData,
            };
            mockCategoryService.Setup(c => c.AddCategory(It.IsAny<Category>(), It.IsAny<IFormFile>())).Returns("Category saved successfully.");


            //Act
            var actual = target.Create(categoryViewModel) as RedirectToActionResult;


            //Assert
            Assert.NotNull(actual);
            Assert.True(target.ModelState.IsValid);
            Assert.Equal("Index", actual.ActionName);
            mockCategoryService.Verify(c => c.AddCategory(It.IsAny<Category>(), It.IsAny<IFormFile>()),Times.Once);
        }


        [Theory]
        [InlineData("Category already exists.")]
        [InlineData("Something went wrong, please try after sometime.")]
        public void Create_SetErrorMessageInTempData_WhenCreateFails(string errorMessage)
        {
            //Arrange
            var categoryViewModel = new CategoryViewModel 
            {
                Name = "Category 1",
                Description = "Description 1" 
            };
            var mockCategoryService = new Mock<ICategoryService>();
            var mockDataProvider = new Mock<ITempDataProvider>();
            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockDataProvider.Object);
            var target = new CategoryController(mockCategoryService.Object)
            {
                TempData = tempData,
            };
            mockCategoryService.Setup(c => c.AddCategory(It.IsAny<Category>(), It.IsAny<IFormFile>())).Returns(errorMessage);




            //Act
            var actual = target.Create(categoryViewModel) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            Assert.True(target.ModelState.IsValid);
            Assert.Equal(categoryViewModel, actual.Model);
            mockCategoryService.Verify(c => c.AddCategory(It.IsAny<Category>(), It.IsAny<IFormFile>()), Times.Once);
        }

        [Fact]
        public void Details_ReturnsNotFound_whenCategoryNotFound()
        {
            //Arrenge
            var mockcategoryService = new Mock<ICategoryService>();
            mockcategoryService.Setup(c => c.GetCategory(1)).Returns<Category>(null);
            var target = new CategoryController(mockcategoryService.Object);

            //Act
            var actual = target.Details(1) as NotFoundResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.NotFound, actual.StatusCode);
            mockcategoryService.Verify(c => c.GetCategory(1), Times.Once);
        }

        [Fact]
        public void Details_ReturnsView_WhenCategoryFound()
        {
            //Arrenge
            var categoryId = 1;
            var category = new Category()
            {
                CategoryId = categoryId,
                Name = "Category 1",
                Description = "Description 1"
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            var target = new CategoryController(mockCategoryService.Object);
            mockCategoryService.Setup(c => c.GetCategory(categoryId)).Returns(category);

            //Act
            var actual = target.Details(categoryId) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            mockCategoryService.Verify(c => c.GetCategory(categoryId), Times.Once);

            
        }


        [Fact]
        public void Edit_ReturnsNotFound_whenCategoryNotFound()
        {
            //Arrenge
            var mockcategoryService = new Mock<ICategoryService>();
            mockcategoryService.Setup(c => c.GetCategory(1)).Returns<Category>(null);
            var target = new CategoryController(mockcategoryService.Object);

            //Act
            var actual = target.Edit(1) as NotFoundResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.NotFound, actual.StatusCode);
            mockcategoryService.Verify(c => c.GetCategory(1),Times.Once);
        }

        [Fact]
        public void Edit_ReturnsView_WhenCategoryFound()
        {
            var categoryId = 1;
            var category = new Category()
            {
                CategoryId = categoryId,
                Name = "Category 1",
                Description = "Description 1"
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            var target = new CategoryController(mockCategoryService.Object);
            mockCategoryService.Setup(c => c.GetCategory(categoryId)).Returns(category);

            //Act
            var actual = target.Edit(categoryId) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            mockCategoryService.Verify(c => c.GetCategory(categoryId), Times.Once);
        }

        [Theory]
        [InlineData("Category already exists.")]
        [InlineData("Something went wrong, please try after sometime.")]

        public void Edit_SetErrorMessageInTempData_WhenModificationFails(string errorMessage)
        {
            //Arrange
            var categoryId = 1;
            var category = new Category()
            {
                CategoryId = 1,
                Name = "Category 1",
                Description = "Description 1"
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            mockCategoryService.Setup(c => c.ModifyCategory(category)).Returns(errorMessage);


            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockTempDataProvider.Object);

            var target = new CategoryController(mockCategoryService.Object)
            {
                TempData = tempData
            };


            //Act
            var actual = target.Edit(category) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal(category, actual.Model);
            mockCategoryService.Verify(c => c.ModifyCategory(category), Times.Once);
        }


        [Fact]
        public void Edit_ReturnsRedirectToActionResult_WhenCategoryUpdatedSuccessfully()
        {
            //Arrenge
            var categoryId = 1;
            var category = new Category()
            {
                CategoryId = 1,
                Name = "Category 1",
                Description = "Description 1"
            };
            var mockCategoryService = new Mock<ICategoryService>();
            var mockDataProvider = new Mock<ITempDataProvider>();
            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockDataProvider.Object);
            var target = new CategoryController(mockCategoryService.Object)
            {
                TempData = tempData,
            };
            mockCategoryService.Setup(c => c.ModifyCategory(category));


            //Act
            var actual = target.Edit(category) as RedirectToActionResult;


            //Assert
            Assert.NotNull(actual);
            Assert.True(target.ModelState.IsValid);
            Assert.Equal("Index", actual.ActionName);
            mockCategoryService.Verify(c => c.ModifyCategory(category), Times.Once);
        }

        [Fact]
        public void Edit_ReturnView_withModelStateIsInValid()
        {
            //Arrenge
            
            var category = new Category { Description = "Category 1" };
            var mockCategoryService = new Mock<ICategoryService>();
            var target = new CategoryController(mockCategoryService.Object);

            target.ModelState.AddModelError("Name", "Name is required.");


            //Act
            var actual = target.Edit(category) as ViewResult;


            //Assert
            Assert.NotNull(actual);
            Assert.Equal(category, actual.Model);
            Assert.False(target.ModelState.IsValid);
        }

        [Fact]
        public void Delete_ReturnsNotFound_whenCategoryNotFound()
        {
            //Arrenge
            var mockcategoryService = new Mock<ICategoryService>();
            mockcategoryService.Setup(c => c.GetCategory(1)).Returns<Category>(null);
            var target = new CategoryController(mockcategoryService.Object);

            //Act
            var actual = target.Delete(1) as NotFoundResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal((int)HttpStatusCode.NotFound, actual.StatusCode);
            mockcategoryService.Verify(c => c.GetCategory(1), Times.Once);
        }

        [Fact]
        public void Delete_ReturnsView_WhenCategoryFound()
        {
            //Arrenge
            var categoryId = 1;
            var category = new Category()
            {
                CategoryId = categoryId,
                Name = "Category 1",
                Description = "Description 1"
            };

            var mockCategoryService = new Mock<ICategoryService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            var target = new CategoryController(mockCategoryService.Object);
            mockCategoryService.Setup(c => c.GetCategory(categoryId)).Returns(category);

            //Act
            var actual = target.Delete(categoryId) as ViewResult;

            //Assert
            Assert.NotNull(actual);
            mockCategoryService.Verify(c => c.GetCategory(categoryId), Times.Once);
        }

        [Theory]
        [InlineData("Category deleted successfully.")]
        [InlineData("Something went wrong, please try after sometimes.")]
        public void DeleteConfirmed(string errorMessage)
        {

            var mockCategoryService = new Mock<ICategoryService>();
            var mockTempDataProvider = new Mock<ITempDataProvider>();
            mockCategoryService.Setup(c => c.RemoveCategory(1)).Returns(errorMessage);


            var tempData = new TempDataDictionary(new DefaultHttpContext(), mockTempDataProvider.Object);

            var target = new CategoryController(mockCategoryService.Object)
            {
                TempData = tempData
            };


            //Act
            var actual = target.DeleteConfirmed(1) as RedirectToActionResult;

            //Assert
            Assert.NotNull(actual);
            Assert.Equal("Index", actual.ActionName);
            mockCategoryService.Verify(c => c.RemoveCategory(1), Times.Once);
        }



    }
}
