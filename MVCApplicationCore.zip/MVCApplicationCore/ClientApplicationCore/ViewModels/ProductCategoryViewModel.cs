﻿namespace ClientApplicationCore.ViewModels
{
    public class ProductCategoryViewModel
    {

        public int CategoryId { get; set; }

        public string Name { get; set; }

    }
}
