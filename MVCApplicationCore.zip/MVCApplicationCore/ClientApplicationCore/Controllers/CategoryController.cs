﻿using ClientApplicationCore.Infrastructure;
using ClientApplicationCore.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection.KeyManagement.Internal;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ClientApplicationCore.Controllers
{
    [Authorize]
    public class CategoryController : Controller
    {
        private readonly IHttpClientService _httpClientService;
        private readonly IConfiguration _configuration;
        private string endPoint;

        public CategoryController(IHttpClientService httpClientService, IConfiguration configuration)
        {
            _httpClientService = httpClientService;
            _configuration = configuration;
            endPoint = _configuration["EndPoint:CivicaApi"];
        }

        public IActionResult Index()
        {
            ServiceResponse<IEnumerable<CategoryViewModel>> response = new ServiceResponse<IEnumerable<CategoryViewModel>>();
            
            response = _httpClientService.ExecuteApiRequest<ServiceResponse<IEnumerable<CategoryViewModel>>>
                ($"{endPoint}Category/GetAllCategories", HttpMethod.Get, HttpContext.Request);

            if (response.Success)
            {
                return View(response.Data);
            }

            return View(new List<CategoryViewModel>());
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public IActionResult Create(AddCategoryViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                
                string apiUrl = $"{endPoint}Category/Create";
                var response = _httpClientService.PostHttpResponseMessage<AddCategoryViewModel>(apiUrl, viewModel, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;

                    return RedirectToAction("Index");


                }
                else
                {
                    string errorMessage = response.Content.ReadAsStringAsync().Result;
                    var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorMessage);
                    if (errorMessage != null)
                    {
                        TempData["errorMessage"] = errorResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                    }

                }
            }
            return View(viewModel);
        }

        public IActionResult Details(int id)
        {
            
            var apiUrl = $"{endPoint}Category/GetCategoryById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateCategoryViewModel>(apiUrl, HttpContext.Request);

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateCategoryViewModel>>(data);

                if(serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }

            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateCategoryViewModel>>(errorData);

                if(errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                }
                return RedirectToAction("Index");
            }


        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            
            var apiUrl = $"{endPoint}Category/GetCategoryById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<UpdateCategoryViewModel>(apiUrl, HttpContext.Request);

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateCategoryViewModel>>(data);

                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }

            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<UpdateCategoryViewModel>>(errorData);

                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                }
                return RedirectToAction("Index");
            }


        }

        [HttpPost]
        public IActionResult Edit(UpdateCategoryViewModel updateCategory)
        {
            if(ModelState.IsValid)
            {
                
                var apiUrl = $"{endPoint}Category/ModifyCategory";
                HttpResponseMessage response = _httpClientService.PutHttpResponseMessage(apiUrl, updateCategory, HttpContext.Request);
                if (response.IsSuccessStatusCode)
                {
                    string successResponse = response.Content.ReadAsStringAsync().Result;
                    var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(successResponse);
                    TempData["successMessage"] = serviceResponse.Message;

                    return RedirectToAction("Index");


                }
                else
                {
                    string errorMessage  = response.Content.ReadAsStringAsync().Result;
                    var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<string>>(errorMessage);
                    if (errorMessage != null)
                    {
                        TempData["errorMessage"] = errorResponse.Message;
                    }
                    else
                    {
                        TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                    }
                  
                }
            }
            return View(updateCategory);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            
            var apiUrl = $"{endPoint}Category/GetCategoryById/" + id;
            var response = _httpClientService.GetHttpResponseMessage<CategoryViewModel>(apiUrl, HttpContext.Request);

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                var serviceResponse = JsonConvert.DeserializeObject<ServiceResponse<CategoryViewModel>>(data);

                if (serviceResponse != null && serviceResponse.Success && serviceResponse.Data != null)
                {
                    return View(serviceResponse.Data);
                }
                else
                {
                    TempData["errorMessage"] = serviceResponse.Message;
                    return RedirectToAction("Index");
                }

            }
            else
            {
                string errorData = response.Content.ReadAsStringAsync().Result;
                var errorResponse = JsonConvert.DeserializeObject<ServiceResponse<CategoryViewModel>>(errorData);

                if (errorResponse != null)
                {
                    TempData["errorMessage"] = errorResponse.Message;
                }
                else
                {
                    TempData["errorMessage"] = "Something went wrong. Please try after sometime.";
                }
                return RedirectToAction("Index");
            }
        }

        public IActionResult DeleteConfirmed(int categoryId)
        {
            
            var apiUrl = $"{endPoint}Category/Remove/" + categoryId;


            var response = _httpClientService.ExecuteApiRequest<ServiceResponse<string>>($"{apiUrl}",HttpMethod.Delete,HttpContext.Request); 
            if (response.Success)
            {
                
                TempData["successMessage"] = response.Message;

                return RedirectToAction("Index");


            }
            else
            {

                TempData["errorMessage"] = response.Message;
                return RedirectToAction("Index");
            }
            
        }

    }
    
}
