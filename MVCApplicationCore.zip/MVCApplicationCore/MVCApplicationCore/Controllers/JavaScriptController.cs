﻿using Microsoft.AspNetCore.Mvc;

namespace MVCApplicationCore.Controllers
{
    public class JavaScriptController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
