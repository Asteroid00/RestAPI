﻿using Microsoft.AspNetCore.Mvc;
using MVCApplicationCore.Data;

namespace MVCApplicationCore.Controllers
{
    [Route("transferdata")]
    public class ViewBagViewDataTempDataController : Controller
    {
        private AppDbContext _context;

        public ViewBagViewDataTempDataController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("viewbagexample")]
        public IActionResult Index()
        {
            ViewBag.ShubhamPanchal = "Hello, Shubham Panchal from viewbag!";
            return View();
        }

        [HttpGet("viewdata")]

        public IActionResult ViewDataExample()
        {
            ViewData["Message"] = "Hello, Shubham Panchal From viewdata!";
            return View();
        }

        [HttpGet("viewdatatypecasting")]
        public IActionResult ViewDataExample1()
        {
            var categories = _context.Categories.ToList();
            ViewData["categories"] = categories;
            return View();
        }

        [HttpGet("tempdata")]

        public IActionResult TempDataExample()
        {
            TempData["Message"] = "Hello,Shubham Panchal From tempdata!";
            return RedirectToAction("NewAction");
        }

        [HttpGet("NewAction")]
        public IActionResult NewAction()
        {
            return View();
        }

    }
}
